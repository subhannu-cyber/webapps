// Tempel URL Web App dari Google Apps Script Anda di sini
// (Deploy > Manage deployments > Web app URL, diakhiri "/exec")
export const SCRIPT_URL = "";
